package com.samsung.biz.users.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.users.vo.UserVO;
import com.samsung.biz.utills.JDBCUtils;

public class UserDAO {

	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	/*
	 * public boolean login(String id, String password) { boolean flag = false;
	 * conn = JDBCUtils.getConnection(); String sql =
	 * "select * from users where id=?"; try { ps = conn.prepareStatement(sql);
	 * rs = ps.executeQuery(); if (rs.next()) { if
	 * (password.equals(rs.getObject("password"))) { flag = true; } } } catch
	 * (SQLException e) { e.printStackTrace(); } finally { JDBCUtils.close(conn,
	 * ps, rs); } return flag;
	 * 
	 * }
	 */

	public UserVO login(UserVO vo) {
		conn = JDBCUtils.getConnection();
		UserVO user = null;
		String sql = "select * from users where id=? and password=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getId());
			ps.setString(2, vo.getPassword());
			rs = ps.executeQuery();
			if (rs.next()) {
				user = new UserVO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, ps, rs);
		}
		return user;

	}
}
