package com.huser.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huser.dao.huserDAO;
import com.huser.vo.huserVO;

@WebServlet("/regMember.do")
public class RegMember extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");

		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		int age = Integer.parseInt(request.getParameter("age"));
		int gender = Integer.parseInt(request.getParameter("gender"));

		huserVO vo = new huserVO();
		vo.setName(name);
		vo.setPassword(password);
		vo.setEmail(email);
		vo.setAge(age);
		vo.setGender(gender);

		huserDAO dao = new huserDAO();
		dao.regMember(vo);
		
		response.sendRedirect("MemberList.jsp");
	}

}
