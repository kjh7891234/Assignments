package com.huser.vo;

public class huserVO {
	/*
	 * seq number(5) primary key, name varchar2(20) not null, password
	 * varchar2(20) not null, email varchar2(50) not null, age number(3) default
	 * 0, gender number(1) not null
	 */
	private int seq;
	private String name, password, email;
	private int age, gender;

	public huserVO() {
		super();
	}

	public huserVO(int seq, String name, String password, String email,
			int age, int gender) {
		super();
		this.seq = seq;
		this.name = name;
		this.password = password;
		this.email = email;
		this.age = age;
		this.gender = gender;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "huserVO [seq=" + seq + ", name=" + name + ", password="
				+ password + ", email=" + email + ", age=" + age + ", gender="
				+ gender + "]";
	}

}