package com.huser.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.huser.utils.JDBCUtils;
import com.huser.vo.huserVO;

/*create table husers(
 seq number(5) primary key,
 name varchar2(20) not null,
 password varchar2(20) not null,
 email varchar2(50) not null,
 age number(3) default 0,
 gender number(1) not null
 )
 */

public class huserDAO {

	Connection con = JDBCUtils.getConnection();
	ResultSet rs = null;
	PreparedStatement ps = null;

	public void regMember(huserVO vo) {
		String sql = "insert into husers values (hseq.nextval, ?, ?, ?, ?, ?)";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, vo.getName());
			ps.setString(2, vo.getPassword());
			ps.setString(3, vo.getEmail());
			ps.setInt(4, vo.getAge());
			ps.setInt(5, vo.getGender());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(con, ps, rs);
		}

	}

	public ArrayList<huserVO> getMemberList() {
		ArrayList<huserVO> list = new ArrayList<huserVO>();
		huserVO vo = null;
		String sql = "select * from husers";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				vo = new huserVO(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getInt(6));
				list.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(con, ps, rs);
		}
		return list;
	}

}
