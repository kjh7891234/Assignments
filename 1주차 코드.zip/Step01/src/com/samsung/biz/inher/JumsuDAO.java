package com.samsung.biz.inher;

public class JumsuDAO {

}
