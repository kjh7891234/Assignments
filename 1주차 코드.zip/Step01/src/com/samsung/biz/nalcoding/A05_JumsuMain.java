package com.samsung.biz.nalcoding;

public class A05_JumsuMain {

	public static void main(String[] args) {
		A05_JumsuDAO hong = new A05_JumsuDAO("홍길동", 95, 75, 80, 0, 0);
		hong.display();

	}

}
