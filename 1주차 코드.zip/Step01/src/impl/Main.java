package impl;

public class Main {
	public static void main(String[] args) {
		Jumsu hong = new Two("홍길동", 100, 96);
		Jumsu im = new Three("홍길동", 100, 96,85);
		Jumsu jimea = new Four("홍길동", 100, 96, 64,78);
				
	}
}
