package com.samsung.employee;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InsertEmp {
	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			// 1단계 -> 사용한 클래스를 올리자
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2단계 -> DB 연결
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(url, "hr", "hr");

			// 3단계 -> Query 준비
			// PreparedStatement 객체는 쿼리 실행 전에 해야 할 일에 대한 메소드를 가지고 있다.
			String sql = "insert into emp (id,name,password,hire,salary,commission,did) values ((select nvl(max(id),0)+1 from emp), ?, ?, sysdate,?,?,?)";
			ps = conn.prepareStatement(sql);

			// 4단계 -> 쿼리에 들어갈 변수들을 세팅하는 작업
			ps.setString(1, "Im");
			ps.setString(2, "123");
			ps.setInt(3, 5000);
			ps.setDouble(4, 0.05);
			ps.setInt(5, 100);

			// 5단계 -> 쿼리를 실행하고, 결과값을 받아 온다.
			int cnt = ps.executeUpdate();
			System.out.println(cnt + "개 정상 입력되었습니다.");

			// 6단계 -> 받아온 결과값을 처리한다.
			

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 7단계 -> 최근 것부터 닫는다.
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
