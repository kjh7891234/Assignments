package com.samsung.emp.view;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateBoard")
public class UpdateBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			// 1단계 -> 사용한 클래스를 올리자
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// 2단계 -> DB 연결
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			conn = DriverManager.getConnection(url, "hr", "hr");

			// 3단계 -> Query 준비
			// PreparedStatement 객체는 쿼리 실행 전에 해야 할 일에 대한 메소드를 가지고 있다.
			String sql = "update board set title = ?, content = ? where seq = ?";
			ps = conn.prepareStatement(sql);

			// 4단계 -> 쿼리에 들어갈 변수들을 세팅하는 작업
			ps.setString(1, "새로운 타이틀2");
			ps.setString(2, "새로운 내용2");
			ps.setInt(3, 8);
			
			// 5단계 -> 쿼리를 실행하고, 결과값을 받아 온다.
			int cnt = ps.executeUpdate();

			// 6단계 -> 받아온 결과값을 처리한다.
			System.out.println(cnt + "개 정상 입력되었습니다.");

			// 페이의 view를 지정한 페이지로 이동시킨다.
			response.sendRedirect("getBoardList");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 7단계 -> 최근 것부터 닫는다.
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
