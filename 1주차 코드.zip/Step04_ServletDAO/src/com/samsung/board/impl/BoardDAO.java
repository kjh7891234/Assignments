package com.samsung.board.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.board.vo.BoardVO;
import com.samsung.emp.utils.JDBCUtils;

public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	public void addBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();

			String sql = "insert into board(seq, title, nickname, content, regdate, userid) "
					+ "values( (select nvl(max(seq), 0)+1 from board), ?, ?, ?, sysdate, 'guest')";

			ps = conn.prepareStatement(sql);

			// 4단계 -> 쿼리에 들어갈 변수들을 세팅하는 작업
			ps.setString(1, "새로운 타이틀");
			ps.setString(2, "새로운 이름");
			ps.setString(3, "새로운 내용");

			// 5단계 -> 쿼리를 실행하고, 결과값을 받아 온다.
			int cnt = ps.executeUpdate();

			// 6단계 -> 받아온 결과값을 처리한다.
			System.out.println(cnt + "개 삽입되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 7단계 -> 최근 것부터 닫는다.
			JDBCUtils.close(conn, ps, rs);
		}
	}

	public BoardVO getBoard(int seq) {
		BoardVO board = new BoardVO();
		try {
			conn = JDBCUtils.getConnection();

			String sql = "select * from board where seq = ?";
			ps = conn.prepareStatement(sql);

			// 4단계 -> 쿼리에 들어갈 변수들을 세팅하는 작업
			ps.setInt(1, seq);

			// 5단계 -> 쿼리를 실행하고, 결과값을 받아 온다.
			rs = ps.executeQuery();

			// 6단계 -> 받아온 결과값을 처리한다.
			if (rs.next()) {
				board.setSeq(rs.getInt("seq"));
				board.setTitle(rs.getString("title"));
				board.setNickname(rs.getString("nickname"));
				board.setRegdate(rs.getDate("regdate"));
				board.setCnt(rs.getInt("cnt"));
				board.setUserid(rs.getString("userid"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, ps, rs);
		}
		return board;

	}

	public ArrayList<BoardVO> getBoardList() {
		ArrayList<BoardVO> list = new ArrayList<>();
		BoardVO board = null;

		Connection con = JDBCUtils.getConnection();
		try {
			ps = con.prepareStatement("select * from board");
			rs = ps.executeQuery();
			while (rs.next()) {
				board = new BoardVO(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getDate(5),
						rs.getInt(6), rs.getString(6));
				list.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		JDBCUtils.close(con, ps, rs);
		return list;
	}

	public void UpdateBoard(int seq) {
		Connection con = JDBCUtils.getConnection();
		try {
			ps = con.prepareStatement("update board set title=?, content=? where seq =?");
			ps.setString(1, "고친 것 제목");
			ps.setString(2, "고친 내용");
			ps.setInt(3, seq);
			int cnt = ps.executeUpdate();
			System.out.println(cnt + "개의 행이 업데이트되엇당 하하");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(con, ps, rs);
		}

	}
	
	public void DeleteBoard(int seq) {
		Connection con = JDBCUtils.getConnection();
		try {
			ps = con.prepareStatement("delete from board where seq = ?");
			ps.setInt(1, seq);
			int cnt = ps.executeUpdate();
			System.out.println(cnt + "개의 행이  삭제되엇당 하하");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(con, ps, rs);
		}

	}
}
