package com.samsung.biz.board.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.samsung.biz.board.BoardService;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.biz.common.JDBCUtils;

@Repository("fileDAO")
public class FileDAO implements BoardService {
	private Connection conn = null;
	private ResultSet rs = null;
	private PreparedStatement ps = null;

	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		System.out.println("FileDAO");
		System.out.println(vo);

		BoardVO board = null;
		ArrayList<BoardVO> boardList = new ArrayList<>();
		String sql = "";
		try {
			conn = JDBCUtils.getConnection();

			if (vo.getSearchCondition().equals("TITLE")) {
				sql = "select * from board where title like '%' || ? || '%'";
			} else if (vo.getSearchCondition().equals("CONTENT")) {
				sql = "select * from board where content like '%' || ? || '%'";
			}

			ps = conn.prepareStatement(sql);

			ps.setString(1, vo.getSearchKeyword());
			rs = ps.executeQuery();
			while (rs.next()) {
				board = new BoardVO(rs.getInt("seq"), rs.getString("title"),
						rs.getString("nickname"), rs.getString("content"),
						rs.getDate("regdate"), rs.getInt("cnt"),
						rs.getString("userid"));
				boardList.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, ps, conn);
		}
		return boardList;
	}

	public BoardVO getBoard(BoardVO vo) {
		BoardVO board = null;
		try {
			conn = JDBCUtils.getConnection();
			String sql = "select * from board where seq = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, vo.getSeq());
			rs = ps.executeQuery();
			if (rs.next()) {
				board = new BoardVO(rs.getInt("seq"), rs.getString("title"),
						rs.getString("nickname"), rs.getString("content"),
						rs.getDate("regdate"), rs.getInt("cnt"),
						rs.getString("userid"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, ps, conn);
		}
		return board;
	}

	public void addBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			String sql = "insert into board(seq,title,nickname,content,userid) values((select nvl(max(seq),0)+1 from board),?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getTitle());
			ps.setString(2, vo.getNickname());
			ps.setString(3, vo.getContent());
			ps.setString(4, vo.getUserid());
			int result = ps.executeUpdate();

			System.out.println(result + "개의 레코드가 삽입되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(ps, conn);
		}
	}

	public void updateBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			String sql = "update board set title=?, content=? where seq = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getTitle());
			ps.setString(2, vo.getContent());
			ps.setInt(3, vo.getSeq());
			int result = ps.executeUpdate();

			System.out.println(result + "개의 레코드가 업데이트 되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(ps, conn);
		}
	}

	public void deleteBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			String sql = "delete from board where seq = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, vo.getSeq());
			int result = ps.executeUpdate();

			System.out.println(result + "개의 레코드가 삭제 되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(ps, conn);
		}
	}
}
