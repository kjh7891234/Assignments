package com.samsung.biz.board.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.samsung.biz.board.BoardService;

@Service("boardService")
public class BoardServiceImpl {
	
	@Autowired
	@Qualifier("boardDAO")
	private BoardService boardDAO;

	public BoardService getBoardDAO() {
		return boardDAO;
	}

	public void setBoardDAO(BoardService boardDAO) {
		this.boardDAO = boardDAO;
	}

}
