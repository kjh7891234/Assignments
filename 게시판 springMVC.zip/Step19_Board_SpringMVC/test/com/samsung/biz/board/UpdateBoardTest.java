package com.samsung.biz.board;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

public class UpdateBoardTest {
	public static void main(String[] args) {
		
		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"applicationContext.xml"); 
		
		BoardVO vo = (BoardVO) factory.getBean("boardVO");
		vo.setTitle("New Title");
		vo.setContent("New Content");
		vo.setSeq(1);

		BoardDAO dao = (BoardDAO) factory.getBean("boardDAO");
		dao.updateBoard(vo);
	}
}
