package com.samsung.biz.board;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.impl.BoardServiceImpl;
import com.samsung.biz.board.vo.BoardVO;

public class GetBoardListTest {
	public static void main(String[] args) {

		ApplicationContext factory = new ClassPathXmlApplicationContext(
				"applicationContext.xml");

		BoardVO vo = (BoardVO) factory.getBean("boardVO");
		vo.setSearchCondition("TITLE");
		vo.setSearchKeyword("");

		BoardServiceImpl bs = (BoardServiceImpl) factory.getBean("boardService");
		BoardService dao = bs.getBoardDAO();

		ArrayList<BoardVO> boardList = dao.getBoardList(vo);
		for (BoardVO board : boardList) {
			System.out.println(board);
		}
	}
}
