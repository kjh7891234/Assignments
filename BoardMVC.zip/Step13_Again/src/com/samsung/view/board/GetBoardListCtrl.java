package com.samsung.view.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;

@WebServlet("/getBoardList")
public class GetBoardListCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		if (id == null) {
			response.sendRedirect("login.jsp");
			return;
		}

		String searchCondition = "";
		String searchKeyword = "";
		if (request.getParameter("searchCondition") == null) {
			searchCondition = "TITLE";
		} else {
			searchCondition = request.getParameter("searchCondition");
		}
		
		if (request.getParameter("searchKeyword") == null) {
			searchKeyword = "";
		} else {
			searchKeyword = request.getParameter("searchKeyword");
		}

		BoardVO vo = new BoardVO();
		vo.setSearchCondition(searchCondition);
		vo.setSearchKeyword(searchKeyword);

		BoardDAO dao = new BoardDAO();
		ArrayList<BoardVO> boardList = dao.getBoardList(vo);

		request.setAttribute("list", boardList);
		// RequestDispatcher view =
		// request.getRequestDispatcher("getBoardList.jsp");
		// view.forward(request, response);
		request.getRequestDispatcher("getBoardList.jsp").forward(request,
				response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		doGet(request, response);
	}

}
