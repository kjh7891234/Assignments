package com.samsung.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.biz.common.JDBCUtils;
import com.samsung.biz.user.vo.UserVO;

public class UserDAO {
	private Connection conn = JDBCUtils.getConnection();
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	public UserVO login(UserVO vo) {
		System.out.println(vo);
		UserVO user = null;

		try {

			String sql = "select * from users where id=? and password=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, vo.getId());
			ps.setString(2, vo.getPassword());
			rs = ps.executeQuery();
			if (rs.next()) {

				user = new UserVO();
				user.setId(rs.getString("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, ps, conn);
		}
		return user;
	}

	public void logout() {
		
	}
}
