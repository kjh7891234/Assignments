package com.samsung.view.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.do")
public class DispatcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String uri = request.getRequestURI();
		String path = uri.substring(uri.lastIndexOf("/"));
		System.out.println(path);

		/*String view = "";
		if (path.equals("/login.do")) {
			LoginController login = new LoginController();
			view = login.handleRequest(request, response);
			request.getRequestDispatcher(view).forward(request, response);
		} else if (path.equals("/logout.do")) {
			LogoutController logout = new LogoutController();
			view = logout.handleRequest(request, response);
			request.getRequestDispatcher(view).forward(request, response);
		}*/
		
		// /login.do 요청에 따른 필요한 자바 객체를 리턴받아 사용할 목적
		// 객체만 관리하는 클래스를 따로 빼서 작성하면
		// 파일이 증감되더라도 이 서블릿을 수정할 필요가 없다.
		HandlerMapping mapping = new HandlerMapping();
		Controller ctrl = mapping.getController(path);
		
		String view = ctrl.handleRequest(request, response);
		request.getRequestDispatcher(view).forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		doGet(request, response);
	}

}
