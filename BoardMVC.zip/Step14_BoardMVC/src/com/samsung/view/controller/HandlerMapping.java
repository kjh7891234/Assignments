package com.samsung.view.controller;

import java.util.HashMap;

import com.samsung.view.board.AddBoardController;
import com.samsung.view.board.DeleteBoardController;
import com.samsung.view.board.GetBoardController;
import com.samsung.view.board.GetBoardListController;
import com.samsung.view.board.UpdateBoardController;
import com.samsung.view.user.LoginController;
import com.samsung.view.user.LogoutController;

public class HandlerMapping {

	private HashMap<String, Controller> mappings = null;

	public HandlerMapping() {
		mappings = new HashMap<>();
		mappings.put("/login.do", new LoginController());
		mappings.put("/logout.do", new LogoutController());

		mappings.put("/addBoard.do", new AddBoardController());
		mappings.put("/deleteBoard.do", new DeleteBoardController());
		mappings.put("/getBoard.do", new GetBoardController());
		mappings.put("/getBoardList.do", new GetBoardListController());
		mappings.put("/updateBoard.do", new UpdateBoardController());
	}

	public Controller getController(String path) {
		return mappings.get(path);
	}

}
