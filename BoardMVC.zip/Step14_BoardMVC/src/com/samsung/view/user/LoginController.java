package com.samsung.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.user.impl.UserDAO;
import com.samsung.biz.user.vo.UserVO;
import com.samsung.view.controller.Controller;

public class LoginController implements Controller{
	
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		String id = request.getParameter("id");
		String password = request.getParameter("password");

		UserVO vo = new UserVO();
		vo.setId(id);
		vo.setPassword(password);

		UserDAO dao = new UserDAO();
		UserVO user = dao.login(vo);

		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("name", user.getName());
			session.setAttribute("id", user.getId());
			return "getBoardList.do";
		} else {
			return "login.jsp";
		}
	}
}
