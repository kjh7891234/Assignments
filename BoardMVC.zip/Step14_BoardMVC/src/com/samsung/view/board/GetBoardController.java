package com.samsung.view.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.biz.board.impl.BoardDAO;
import com.samsung.biz.board.vo.BoardVO;
import com.samsung.view.controller.Controller;

public class GetBoardController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		if (id == null) {
			return "login.jsp";
		}
		BoardVO vo = new BoardVO();
		int seq = Integer.parseInt(request.getParameter("seq"));
		vo.setSeq(seq);

		BoardDAO dao = new BoardDAO();
		BoardVO board = dao.getBoard(vo);
		// System.out.println(board);
		request.setAttribute("board", board);
		return "getBoard.jsp";
	}

}
